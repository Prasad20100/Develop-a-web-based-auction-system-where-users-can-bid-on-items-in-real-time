const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// MySQL database connection
const db = mysql.createConnection({
    host: 'localhost', // Your database host
    user: 'root',      // Your database username
    password: '',      // Your database password
    database: 'auction_system' // Your database name
});

// Connect to the database
db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to the database.');
});

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '../public')));

// User registration endpoint
app.post('/register', async (req, res) => {
    const { name, username, password, role } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        db.query(
            'INSERT INTO users (name, username, password) VALUES (?, ?, ?)',
            [name, username, hashedPassword, role || 'user'],
            (err) => {
                if (err) {
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.status(400).json({ message: 'Username already exists' });
                    }
                    return res.status(500).json({ message: 'Server error during registration.' });
                }
                res.status(201).json({ message: 'User registered successfully.' });
            }
        );
    } catch (error) {
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

// Login users
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
        if (err || results.length === 0) return res.status(400).json({ message: 'User not found.' });

        const user = results[0];
        const match = await bcrypt.compare(password, user.password);

        if (!match) return res.status(400).json({ message: 'Invalid password.' });

        const token = jwt.sign({ id: user.id, role: user.role }, 'your_jwt_secret', { expiresIn: '1h' });
        res.json({ token, role: user.role });
    });
});

// Middleware to authenticate and authorize
const auth = (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, 'your_jwt_secret', (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Example of a protected route
app.get('/dashboard', auth, (req, res) => {
    res.json({ message: `Welcome ${req.user.role}!` });
});

// Route to add a product
app.post('/add-product', (req, res) => {
    const product = req.body;
    const query = 'INSERT INTO products (name, description, price, category) VALUES (?, ?, ?, ?)';
    
    db.query(query, [product.name, product.description, product.price, product.category], (err, result) => {
        if (err) {
            return res.status(500).send('Error adding product');
        }
        res.send('Product added successfully');
    });
});

// Route to get products
app.get('/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching products');
        }
        res.json(results);
    });
});

// Route to delete a product
app.delete('/products/:id', (req, res) => {
    const productId = req.params.id;

    const query = 'DELETE FROM products WHERE id = ?';
    db.query(query, [productId], (err, results) => {
        if (err) {
            console.error('Error deleting product:', err);
            return res.status(500).send('Failed to delete the product.');
        }
        if (results.affectedRows === 0) {
            return res.status(404).send('Product not found.');
        }
        res.status(200).send('Product deleted successfully.');
    });
});

// Endpoint to handle payment submission
app.post('/submit-payment', (req, res) => {
    const { bankName, accountNumber, ifscCode, amount } = req.body;
    const sql = 'INSERT INTO payments (bankName, accountNumber, ifscCode, amount) VALUES (?, ?, ?, ?)';

    db.query(sql, [bankName, accountNumber, ifscCode, amount], (err) => {
        if (err) {
            return res.status(500).send('Error saving payment');
        }
        res.status(200).send('Payment saved successfully');
    });
});

// Route to get payments
app.get('/payments', (req, res) => {
    db.query('SELECT * FROM payments', (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching payments');
        }
        res.json(results);
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
