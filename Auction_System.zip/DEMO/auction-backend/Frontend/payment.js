document.getElementById('paymentButton').addEventListener('click', function() {
    const form = document.getElementById('paymentForm');
    form.classList.toggle('hidden');
});

document.getElementById('paymentSubmissionForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const bankName = document.getElementById('bankName').value;
    const accountNumber = document.getElementById('accountNumber').value;
    const ifscCode = document.getElementById('ifscCode').value;
    const amount = document.getElementById('amount').value;

    const paymentInfo = {
        bankName,
        accountNumber,
        ifscCode,
        amount
    };

    fetch('http://localhost:3000/submit-payment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(paymentInfo)
    })
    .then(response => {
        if (!response.ok) throw new Error(' response was not ok');
        return response.text();
    })
    .then(data => {
        const resultDiv = document.getElementById('result');
        resultDiv.classList.remove('hidden');
        resultDiv.innerHTML = `<strong>${data}</strong>`;
        
        // Reset the form
        document.getElementById('paymentSubmissionForm').reset();
        document.getElementById('paymentForm').classList.add('hidden');
    })
    .catch(error => console.error('Error:', error));
});
