document.addEventListener('DOMContentLoaded', async () => {
    const auctionsContainer = document.getElementById('auctions');

    // Fetch auction data from the backend
    try {
        const response = await fetch('http://localhost:3000/products');
        if (!response.ok) throw new Error('Network response was not ok');
        const products = await response.json();

        // Store products in localStorage for state management
        localStorage.setItem('products', JSON.stringify(products));

        // Check if there are products available
        if (products.length === 0) {
            const noProductsMessage = document.createElement('div');
            noProductsMessage.textContent = 'No Products Available';
            noProductsMessage.style.color = 'red';
            noProductsMessage.style.textAlign='center';
            auctionsContainer.appendChild(noProductsMessage);
            return; // Exit if no products are found
        }

        // Display auction items with timers
        products.forEach((product, index) => {
            const auctionItem = document.createElement('div');
            auctionItem.classList.add('auction-item');

            auctionItem.innerHTML = `
                <h3>${product.name}</h3>
                <p><strong>Description:</strong> ${product.description}</p>
                <p><strong>Current Price:</strong> $<span id="currentPrice${index}">${product.price}</span></p>
                <p><strong>Time Remaining:</strong> <span id="timer${index}">20</span> seconds</p>
                <input type="number" id="bidAmount${index}" placeholder="Enter your bid" min="${product.price}" required>
                <button id="bidButton${index}" onclick="placeBid(${index})">Place Bid</button>
               <button id="paymentButton${index}" onclick="handlePayment(${index})">Payment</button>


                <p id="bidMessage${index}" style="color: green;"></p>
                <p id="winnerMessage${index}" style="color: blue;"></p>
                <p id="bidCompleteMessage${index}" style="color: red; display: none;"></p>
            `;
            auctionsContainer.appendChild(auctionItem);
        });
    } catch (error) {
        console.error('Error fetching products:', error);
    }
});

// Track the auction state and timers
let auctionTimers = {};

function startTimer(index) {
    const timerDisplay = document.getElementById(`timer${index}`);
    let timerDuration = 20; 

    auctionTimers[index] = setInterval(() => {
        timerDuration--;
        timerDisplay.textContent = timerDuration;

        if (timerDuration <= 0) {
            clearInterval(auctionTimers[index]);
            disableBidding(index);
        }
    }, 1000); // Set to 1000 ms (1 second) for a more accurate timer
}

// Function to disable bidding
function disableBidding(index) {
    const bidInput = document.getElementById(`bidAmount${index}`);
    const bidButton = document.getElementById(`bidButton${index}`);
    const bidCompleteMessage = document.getElementById(`bidCompleteMessage${index}`);

    bidInput.disabled = true;
    bidButton.disabled = true;
    document.getElementById(`bidMessage${index}`).textContent = 'Bidding has ended.';

    // Display bid completed message
    bidCompleteMessage.textContent = 'Bid Completed';
    bidCompleteMessage.style.display = 'block'; // Show the completed message
}

// Function to handle placing a bid
function placeBid(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const product = products[index];
    const bidAmountInput = document.getElementById(`bidAmount${index}`);
    const bidMessage = document.getElementById(`bidMessage${index}`);
    const currentPriceDisplay = document.getElementById(`currentPrice${index}`);
    const winnerMessage = document.getElementById(`winnerMessage${index}`);

    // Check if the auction has ended
    if (bidMessage.textContent === 'Bidding has ended.') {
        return; // Do nothing if bidding has ended
    }

    const bidAmount = parseFloat(bidAmountInput.value);
    const currentPrice = parseFloat(currentPriceDisplay.textContent);

    // Check if the bid amount is greater than the current price
    if (bidAmount > currentPrice) {
        // Update the product's price by adding the new bid amount
        const newPrice = bidAmount; // Set the new price to the bid amount
        product.price = newPrice; // Update the product's price
        products[index] = product; // Save updated product back to the array
        localStorage.setItem('products', JSON.stringify(products)); // Update localStorage

        // Update the UI
        currentPriceDisplay.textContent = newPrice.toFixed(2); // Display new price
        bidMessage.textContent = 'Bid placed successfully!';

        // Store the highest bidder's name
        const username = prompt("Please enter your name for the bid:");
        if (username) {
            winnerMessage.textContent = `Current Highest Bidder: ${username} with a bid of $${newPrice.toFixed(2)}`;
        }

        bidAmountInput.value = ''; // Clear the input

        // Start or reset the timer
        if (!auctionTimers[index]) {
            startTimer(index); // Start timer only if it's the first bid
        } else {
            resetTimer(index); // Reset the timer if it's not the first bid
        }
    } else {
        bidMessage.textContent = 'Bid must be higher than the current price!';
    }
}

//function for payment
function handlePayment(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const product = products[index];

    // You might want to check if the user is logged in or any other condition before proceeding

    // Redirect to the payment page, passing the product details in the URL
    const paymentUrl = `payment.html?productId=${product.id}&productName=${encodeURIComponent(product.name)}&price=${product.price}`;
    window.location.href = paymentUrl; // Redirect to payment page
}

// Function to reset the timer
function resetTimer(index) {
    const timerDisplay = document.getElementById(`timer${index}`);
    clearInterval(auctionTimers[index]); // Clear the existing timer
    let timerDuration = 20; // Reset the timer duration
    timerDisplay.textContent = timerDuration; // Reset the timer display

    auctionTimers[index] = setInterval(() => {
        timerDuration--;
        timerDisplay.textContent = timerDuration;

        if (timerDuration <= 0) {
            clearInterval(auctionTimers[index]);
            disableBidding(index); // Disable bidding when the time is up
        }
    }, 1000); // Set to 1000 ms (1 second) for a more accurate timer
}
