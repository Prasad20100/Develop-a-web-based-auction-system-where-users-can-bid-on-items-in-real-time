document.addEventListener('DOMContentLoaded', () => {
    const productsList = document.getElementById('products');

    fetch('http://localhost:3000/products')
        .then(response => response.json())
        .then(products => {
            if (products.length > 0) {
                products.forEach(product => {
                    const productItem = document.createElement('li');
                    productItem.className = 'product-item';
                    productItem.innerHTML = `
                        <div class="product-container">
                            <button class="delete-button" data-id="${product.id}">&times;</button>
                            <div class="product-details">
                                <strong>${product.name}</strong> - $${product.price.toFixed(2)}<br>
                                <p>Description: ${product.description}</p>
                                <p>Category: ${product.category}</p>
                            </div>
                        </div>
                    `;
                    productsList.appendChild(productItem);
                });

                // Attach delete functionality
                document.querySelectorAll('.delete-button').forEach(button => {
                    button.addEventListener('click', (event) => {
                        const productId = event.target.getAttribute('data-id');
                        deleteProduct(productId);
                    });
                });
            } else {
                productsList.innerHTML = '<li>No products available.</li>';
            }
        })
        .catch(err => console.error('Error:', err));
});

// Function to delete a product
function deleteProduct(id) {
    fetch(`http://localhost:3000/products/${id}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            // Remove the product from the DOM
            document.querySelector(`.delete-button[data-id="${id}"]`).closest('li').remove();
            alert('Product deleted successfully!');
        } else {
            alert('Failed to delete the product.');
        }
    })
    .catch(err => console.error('Error:', err));
}
