document.addEventListener('DOMContentLoaded', () => {
    const addProductForm = document.getElementById('addProductForm');
    const messageElement = document.getElementById('message');

    addProductForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const product = {
            name: document.getElementById('productName').value,
            description: document.getElementById('productDescription').value,
            price: parseFloat(document.getElementById('productPrice').value),
            category: document.getElementById('productCategory').value,
        };

        fetch('http://localhost:3000/add-product', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(product),
        })
        .then(response => response.text())
        .then(data => {
            messageElement.textContent = data;
            addProductForm.reset(); // Clear the form
        })
        .catch(err => console.error('Error:', err));
    });
});
