// Get the necessary elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const registerLink = document.getElementById('registerLink');
const loginLink = document.getElementById('loginLink');

// Toggle between Login and Register forms
registerLink.addEventListener('click', () => {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
});

loginLink.addEventListener('click', () => {
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
});

// Handle User Registration
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('registerName').value;
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;
    const role = document.getElementById('role').value; // Get selected role

    try {
        // Send registration data to backend
        const response = await fetch('http://localhost:3000/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, username, password, role }), // Send data to server
        });

        const result = await response.json();

        if (response.ok) {
            alert('Registration successful! You can now login.');
            loginForm.style.display = 'block';
            registerForm.style.display = 'none';
        } else {
            alert(result.message || 'Error during registration');
        }
    } catch (error) {
        alert('Error during registration. Please try again.');
    }
});

// Handle User Login and Admin Login
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value; // Get selected role

    if (role === 'admin') {
        // Hardcoded credentials for admin login
        const adminUsername = 'admin';
        const adminPassword = 'admin123';

        if (username === adminUsername && password === adminPassword) {
            alert('Welcome, Admin!');
            window.location.href = 'admin.html'; // Redirect to Admin page
        } else {
            alert('Invalid Admin credentials');
        }
    } else {
        // Handle User Login from the server
        try {
            const response = await fetch('http://localhost:3000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
            });

            const result = await response.json();

            if (response.ok) {
                alert(`Welcome, ${result.name}!`);
                window.location.href = 'products.html'; // Redirect to User's page
            } else {
                alert(result.message || 'Invalid login credentials');
            }
        } catch (error) {
            alert('Error during login. Please try again.');
        }
    }
});
